package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;

import androidx.annotation.NonNull;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
public class ClawOne {
    public Servo clawServo1;
    ClawOne(HardwareMap hardwareMap) {
        clawServo1 = hardwareMap.servo.get("clawServo1");
    }

    public class open implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet){
            clawServo1.setPosition(0.4);
            return false;
        }
    }

    public class close implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet){
            clawServo1.setPosition(0.9);
            return false;
        }
    }
    public Action Close(){
        return new close();
    }

    public Action Open()
    {
        return new open();
    }
}
