package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

@TeleOp(name = "Test2ServosBadr")
public class Test2ServosBadr extends OpMode {
    // --------------------------
    // 1) Make hardware fields
    // 1) Make hardware fields
    // 1) Make hardware fields
    // --------------------------
    private Servo clawServo;
    final double MIN_ANGLE = 30;   // Minimum angle (degrees)
    final double MAX_ANGLE = 120;  // Maximum angle (degrees)
    final double SPEED = 5;        // Speed multiplier for the forward (X) movement

    // For edge detection on the A button
    private boolean previousA = false;

    @Override
    public void init() {
        telemetry.addData("Status", "INIT SEQUENCE LAUNCHED");

        // --------------------------
        // 2) Initialize hardware
        // --------------------------
        clawServo = hardwareMap.servo.get("clawServo");

        // Set direction
        clawServo.setDirection(Servo.Direction.FORWARD);

        clawServo.setPosition(degreesToServoPosition(90)); // Start at 90°
    }

    @Override
    public void loop() {
        claw_function();
    }

    public void claw_function(){
        double currentAngle = servoPositionToDegrees(clawServo.getPosition()); // Get current angle

        // Increase angle if X is pressed and within bounds (forward motion)
        if (gamepad2.x && currentAngle < MAX_ANGLE) {
            currentAngle += SPEED * 180; // Your current logic for moving forward
        }

        // For the A button, we only change the angle once per press.
        boolean currentA = gamepad2.a;
        if (currentA && !previousA && currentAngle > MIN_ANGLE) {
            // Subtract 22.5° which is 1/8 of a 180° rotation.
            currentAngle -= 22.5;
        }
        previousA = currentA;

        // Update servo position with the new angle
        clawServo.setPosition(degreesToServoPosition(currentAngle));
    }

    // Helper method to convert degrees to a servo position (0.0 to 1.0)
    private double degreesToServoPosition(double degrees) {
        return degrees / 180.0;
    }

    // Helper method to convert servo position to degrees
    private double servoPositionToDegrees(double position) {
        return position * 180.0;
    }

    @Override
    public void stop() {
        // Reset the servo position when stopping
        clawServo.setPosition(0);
    }
}
