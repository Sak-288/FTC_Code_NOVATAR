package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

// FTC Hardware
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;

@TeleOp(name = "MECANUM_MockUpTeleOpNOVATARD")
public class MECANUM_MockUpTeleOpNOVATARD extends OpMode {
    // --------------------------
    // 1) Make hardware fields
    // --------------------------
    private DcMotor frontLeftMotor, backLeftMotor, frontRightMotor, backRightMotor, linearSlidesFront1, linearSlidesUp1, linearSlidesFront2, linearSlidesUp2;

    // We’ll keep track of powers if we want to set them to zero in stop()
    private double frontLeftPower, backLeftPower, frontRightPower, backRightPower, linearPowerFront1, linearPowerUp1, linearPowerFront2, linearPowerUp2;

    // For convenience, we can store a variable for drive speed scaling
    private double DRIVE_TRAIN_POWER_FACTOR = 1.0;

    private Servo clawServo1;
    private Servo clawServo2;
    private CRServo linearServo1;
    private CRServo linearServo2;
    private CRServo linearServo3;

    @Override
    public void init() {
        telemetry.addData("Status", "INIT SEQUENCE LAUNCHED");

        // --------------------------
        // 2) Initialize hardware
        // --------------------------
        frontLeftMotor  = hardwareMap.dcMotor.get("leftFront");
        backLeftMotor   = hardwareMap.dcMotor.get("leftBack");
        frontRightMotor = hardwareMap.dcMotor.get("rightFront");
        backRightMotor  = hardwareMap.dcMotor.get("rightBack");
        linearSlidesFront1 = hardwareMap.dcMotor.get("linearSlidesFront1");
        linearSlidesUp1  = hardwareMap.dcMotor.get("linearSlidesUp1");
        linearSlidesFront2 = hardwareMap.dcMotor.get("linearSlidesFront2");
        linearSlidesUp2  = hardwareMap.dcMotor.get("linearSlidesUp2");

        // Set run modes
        frontLeftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backLeftMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        frontRightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        backRightMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        linearSlidesFront1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        linearSlidesUp1.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        linearSlidesFront2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
        linearSlidesUp2.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Zero power behavior
        frontLeftMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backLeftMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        frontRightMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        backRightMotor.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        linearSlidesFront1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        linearSlidesUp1.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        linearSlidesFront2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        linearSlidesUp2.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        // Set directions
        frontRightMotor.setDirection(DcMotor.Direction.REVERSE);
        backRightMotor.setDirection(DcMotor.Direction.REVERSE);
        frontLeftMotor.setDirection(DcMotor.Direction.FORWARD);
        backLeftMotor.setDirection(DcMotor.Direction.FORWARD);
        linearSlidesFront1.setDirection(DcMotor.Direction.FORWARD);
        linearSlidesUp1.setDirection(DcMotor.Direction.REVERSE);
        linearSlidesFront2.setDirection(DcMotor.Direction.FORWARD);
        linearSlidesUp2.setDirection(DcMotor.Direction.REVERSE);

        clawServo1 = hardwareMap.servo.get("clawServo1");
        clawServo2 = hardwareMap.servo.get("clawServo2");

        linearServo1 = hardwareMap.crservo.get("linearServo1");
        linearServo2 = hardwareMap.crservo.get("linearServo2");
        linearServo3 = hardwareMap.crservo.get("linearServo3");


        // Set direction
        clawServo1.setDirection(Servo.Direction.REVERSE);
        clawServo2.setDirection(Servo.Direction.REVERSE);

        linearServo1.setDirection(CRServo.Direction.REVERSE);
        linearServo2.setDirection(CRServo.Direction.FORWARD);
        linearServo3.setDirection(CRServo.Direction.FORWARD);
    }

    @Override
    public void loop() {
        drive_function();
        linearSlidesFront1();
        linearSlidesUp1();
        linearSlidesFront2();
        linearSlidesUp2();
        linearSlidesFront1_bis();
        linearSlidesUp1_bis();
        linearSlidesFront2_bis();
        linearSlidesUp2_bis();
        claw_function1();
        claw_function2();
        linear_claw_function1();
        linear_claw_function2();
        linear_claw_function3();
    }

    public void drive_function() {
        // Adjust speed if certain buttons are pressed
        if (gamepad1.x)      DRIVE_TRAIN_POWER_FACTOR = 0.25;
        else if (gamepad1.a) DRIVE_TRAIN_POWER_FACTOR = 0.50;
        else if (gamepad1.b) DRIVE_TRAIN_POWER_FACTOR = 0.75;
        else if (gamepad1.y) DRIVE_TRAIN_POWER_FACTOR = 1.00;


        // We can call these "rotX" / "rotY"
        double x = -gamepad1.left_stick_x; // Add 1.3 if test doesn't workkkk
        double y = gamepad1.left_stick_y;
        double rx = -gamepad1.right_stick_x;;

        // Denominator ensures we don’t exceed 1.0 in any motor
        double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);

        // Calculate motor powers
        frontLeftPower  = (y + x + rx) / denominator;
        backLeftPower   = (y - x + rx) / denominator;
        frontRightPower = (y - x - rx) / denominator;
        backRightPower  = (y + x - rx) / denominator;

        // Apply scaled power
        frontLeftMotor.setPower(frontLeftPower  * DRIVE_TRAIN_POWER_FACTOR);
        backLeftMotor.setPower(backLeftPower    * DRIVE_TRAIN_POWER_FACTOR);
        frontRightMotor.setPower(frontRightPower * DRIVE_TRAIN_POWER_FACTOR);
        backRightMotor.setPower(backRightPower   * DRIVE_TRAIN_POWER_FACTOR);
    }

    public void linearSlidesFront1(){
        linearPowerFront1 = gamepad2.left_trigger;
        linearSlidesFront1.setPower(linearPowerFront1);
    }

    public void linearSlidesUp1(){
        linearPowerUp1 = gamepad2.left_trigger;
        linearSlidesUp1.setPower(linearPowerUp1);

    }

    public void linearSlidesFront2(){
        linearPowerFront2 = gamepad2.right_trigger;
        linearSlidesFront2.setPower(linearPowerFront2);
    }

    public void linearSlidesUp2(){
        linearPowerUp2 = gamepad2.right_trigger;
        linearSlidesUp2.setPower(linearPowerUp2);
    }

    public void linearSlidesFront1_bis(){
        if(gamepad2.left_bumper){
        linearSlidesFront1.setPower(-1);
        }
    }

    public void linearSlidesUp1_bis(){
        if(gamepad2.left_bumper){
        linearSlidesUp1.setPower(-1);
        }
    }

    public void linearSlidesFront2_bis(){
        if(gamepad2.right_bumper){
        linearSlidesFront2.setPower(-1);
        }
    }

    public void linearSlidesUp2_bis(){
        if(gamepad2.right_bumper){
        linearSlidesUp2.setPower(-1);
        }
    }
    public void linear_claw_function1(){
        double linearClawPower1 = -gamepad2.left_stick_y; // Might not make sense
        linearServo1.setPower(linearClawPower1);
    }
    public void linear_claw_function2(){

        double linearClawPower2 = -gamepad2.left_stick_y; // Might not make sense
        linearServo2.setPower(linearClawPower2);
    }
    public void linear_claw_function3(){

        double linearClawPower3 = -gamepad2.right_stick_y; // Might not make sense
        linearServo3.setPower(linearClawPower3);
    }
    public void claw_function1(){
        if (gamepad2.x) {
            clawServo1.setPosition(0.4);
        }
        if (gamepad2.a) {
            clawServo1.setPosition(0.9);
        }
    }

    public void claw_function2(){
        if (gamepad2.y) {
            clawServo2.setPosition(0.9);
        }
        if (gamepad2.b) {
            clawServo2.setPosition(0.4);
        }
    }

    @Override
    public void stop() {
        // Just set everything to zero
        frontLeftMotor.setPower(0);
        backLeftMotor.setPower(0);
        frontRightMotor.setPower(0);
        backRightMotor.setPower(0);
        linearSlidesFront1.setPower(0);
        linearSlidesUp1.setPower(0);
        clawServo1.setPosition(0);
        linearSlidesFront2.setPower(0);
        linearSlidesUp2.setPower(0);
        clawServo2.setPosition(0);
    }
}
