package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.Servo;

import androidx.annotation.NonNull;
import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
public class LinearArmOne {
    public CRServo linearServo1;
    public CRServo linearServo2;

    LinearArmOne(HardwareMap hardwareMap) {
        linearServo1 = hardwareMap.crservo.get("linearServo1");
        linearServo2 = hardwareMap.crservo.get("linearServo2");

        linearServo1.setDirection(CRServo.Direction.REVERSE);
        linearServo1.setDirection(CRServo.Direction.REVERSE);
    }

    public class clip implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet){
            linearServo1.setPower(1);
            linearServo2.setPower(1);

            return false;
        }
    }

    public class back implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet){
            linearServo1.setPower(-0.75);
            linearServo2.setPower(-0.75);

            return false;
        }
    }

    public class stop implements Action {
        @Override
        public boolean run(@NonNull TelemetryPacket packet){
            linearServo1.setPower(0);
            linearServo2.setPower(0);

            return false;
        }
    }

    public Action Clip(){
        return new clip();
    }

    public Action Back()
    {
        return new back();
    }

    public Action Stop(){
        return new stop();
    }

}