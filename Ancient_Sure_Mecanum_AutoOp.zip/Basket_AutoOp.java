package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.teamcode.MecanumDrive;


@Autonomous(name = "Basket_AutoOp", group = "Autonomous")
public final class Basket_AutoOp extends LinearOpMode {
    @Override
    public void runOpMode() {
        Pose2d beginPose = new Pose2d(-25, -60, Math.toRadians(270));
        MecanumDrive drive = new MecanumDrive(hardwareMap, beginPose);
        LinearArmOne linearArmOne = new LinearArmOne(hardwareMap);
        ClawOne clawOne = new ClawOne(hardwareMap);

        waitForStart();


        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .strafeTo(new Vector2d(-25, -10))
                        .strafeTo(new Vector2d(-40, -10))
                        .strafeTo(new Vector2d(-55, -60))
                        .strafeTo(new Vector2d(-40, -10))
                        .strafeTo(new Vector2d(-53.5, -10))
                        .strafeTo(new Vector2d(-53.5, -60))
                        .strafeTo(new Vector2d(-53.5, -10))
                        .strafeTo(new Vector2d(-61, -10))
                        .strafeTo(new Vector2d(-61, -60))
                        .strafeTo(new Vector2d(-50, -30))
                        .strafeTo(new Vector2d(60, -55))
                        .build());
    }
}
