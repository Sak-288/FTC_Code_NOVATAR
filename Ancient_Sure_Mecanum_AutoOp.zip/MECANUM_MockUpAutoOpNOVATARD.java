package org.firstinspires.ftc.teamcode;

import androidx.annotation.NonNull;

import com.acmerobotics.dashboard.telemetry.TelemetryPacket;
import com.acmerobotics.roadrunner.Action;
import com.acmerobotics.roadrunner.SequentialAction;
import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.CRServo;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;

import org.firstinspires.ftc.teamcode.MecanumDrive;


@Autonomous(name = "MECANUM_MockUpAutoOpNOVATARD", group = "Autonomous")
public final class MECANUM_MockUpAutoOpNOVATARD extends LinearOpMode {
    @Override
    public void runOpMode() {
        Pose2d beginPose = new Pose2d(10, -60, Math.toRadians(270));
        MecanumDrive drive = new MecanumDrive(hardwareMap, beginPose);
        LinearArmOne linearArmOne = new LinearArmOne(hardwareMap);
        ClawOne clawOne = new ClawOne(hardwareMap);

        waitForStart();


        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .afterTime(1, linearArmOne.Clip())
                        .afterTime(2.5, clawOne.Open())
                        .strafeTo(new Vector2d(10, -30))
                        .afterTime( 0.35, linearArmOne.Back())
                        .afterTime(0.75, linearArmOne.Stop())
                        .waitSeconds(1.5)
                        .afterTime(2, linearArmOne.Clip())
                        .afterTime(2.75, linearArmOne.Stop())
                        .afterTime(4.25, clawOne.Close())
                        .afterTime(5.25, linearArmOne.Back())
                        .splineToSplineHeading(new Pose2d(45, -55, Math.toRadians(90)), Math.toRadians(0))
                        .splineToSplineHeading(new Pose2d(0, -40, Math.toRadians(270)), Math.toRadians(0))
                        .afterTime(3.0, linearArmOne.Clip())
                        .afterTime(3.5, clawOne.Open())
                        .strafeTo(new Vector2d(0, -30))
                        .afterTime( 0.35, linearArmOne.Back())
                        .afterTime(0.75, linearArmOne.Stop())
                        .waitSeconds(1.5)
                        .strafeTo(new Vector2d(0, -50))
                        .build());

        beginPose = new Pose2d(64, -52, Math.toRadians(90));
        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .splineToSplineHeading(new Pose2d(28, -35, Math.toRadians(270)), Math.toRadians(0))
                        .splineToSplineHeading(new Pose2d(50, -10, Math.toRadians(270)), Math.toRadians(0))
                        .strafeTo(new Vector2d(45, -45))
                        .strafeTo(new Vector2d(45, -10))
                        .strafeTo(new Vector2d(55, -10))
                        .strafeTo(new Vector2d(55, -45))
                        .strafeTo(new Vector2d(55, -10))
                        .strafeTo(new Vector2d(65, -10))
                        .strafeTo(new Vector2d(65, -45))
                        .build());

        beginPose = new Pose2d(-70, -35, Math.toRadians(270));
        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .afterTime(2, linearArmOne.Clip())
                        .afterTime(2.75, linearArmOne.Stop())
                        .afterTime(4.25, clawOne.Close())
                        .afterTime(5.25, linearArmOne.Back())
                        .strafeTo(new Vector2d(45, -55))
                        .splineToSplineHeading(new Pose2d(-10, -50, Math.toRadians(90)), Math.toRadians(0))
                        .afterTime(1, linearArmOne.Clip())
                        .afterTime(2.5, clawOne.Open())
                        .strafeTo(new Vector2d(-10, -30))
                        .afterTime( 0.35, linearArmOne.Back())
                        .afterTime(0.75, linearArmOne.Stop())
                        .waitSeconds(1.5)
                        .strafeTo(new Vector2d(60, -55))
                        .build());
    }
}
