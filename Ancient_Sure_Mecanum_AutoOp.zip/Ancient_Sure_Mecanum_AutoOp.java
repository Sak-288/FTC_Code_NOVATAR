package org.firstinspires.ftc.teamcode;

import com.acmerobotics.roadrunner.Vector2d;
import com.acmerobotics.roadrunner.Pose2d;
import com.acmerobotics.roadrunner.ftc.Actions;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;


@Autonomous(name = "Ancient_Sure_Mecanum_AutoOp", group = "Autonomous")
public final class Ancient_Sure_Mecanum_AutoOp extends LinearOpMode {
    @Override
    public void runOpMode() {
        Pose2d beginPose = new Pose2d(10, -60, Math.toRadians(270));
        MecanumDrive drive = new MecanumDrive(hardwareMap, beginPose);
        LinearArmOne linearArmOne = new LinearArmOne(hardwareMap);
        ClawOne clawOne = new ClawOne(hardwareMap);

        waitForStart();


        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .afterTime(1, linearArmOne.Clip())
                        .afterTime(2.5, clawOne.Open())
                        .strafeTo(new Vector2d(-10, -27))
                        .afterTime( 0.35, linearArmOne.Back())
                        .afterTime(0.75, linearArmOne.Stop())
                        .waitSeconds(1.5)
                        .afterTime(2, linearArmOne.Clip())
                        .afterTime(2.75, linearArmOne.Stop())
                        .afterTime(4.25, clawOne.Close())
                        .afterTime(5.25, linearArmOne.Back())
                        .splineToSplineHeading(new Pose2d(64, -52, Math.toRadians(90)), Math.toRadians(0))
                        .build());

        beginPose = new Pose2d(64, -52, Math.toRadians(90));
        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .splineToSplineHeading(new Pose2d(0, -40, Math.toRadians(270)), Math.toRadians(0))
                        .afterTime(3.0, linearArmOne.Clip())
                        .afterTime(3.5, clawOne.Open())
                        .strafeTo(new Vector2d(-70, -24))
                        .afterTime( 0.35, linearArmOne.Back())
                        .afterTime(0.75, linearArmOne.Stop())
                        .waitSeconds(1.5)
                        .strafeTo(new Vector2d(-70, -35))
                        .build());

        beginPose = new Pose2d(-70, -35, Math.toRadians(270));
        Actions.runBlocking(
                drive.actionBuilder(beginPose)
                        .strafeTo(new Vector2d(5, -35))
                        .turn(Math.toRadians(180))
                        .splineToConstantHeading(new Vector2d(25, 0), Math.toRadians(90))
                        .build());

        // Actions.runBlocking(
        //      drive.actionBuilder(beginPose)
        //       .strafeTo(new Vector2d(57, -10))
        //    .strafeTo(new Vector2d(57, -50))
        //    .strafeTo(new Vector2d(57, -10))
        //    .strafeTo(new Vector2d(67, -10))
        //        .build());

        //Actions.runBlocking(
        //      drive.actionBuilder(beginPose)
        //          .strafeTo(new Vector2d(67, -50))
        //       .strafeTo(new Vector2d(47, -50))
        //        .splineToSplineHeading(new Pose2d(47, -50, Math.toRadians(180)), Math.toRadians(180))
        //       .splineToSplineHeading(new Pose2d(0, -35, Math.toRadians(0)), Math.toRadians(0))
        //      .build());

        //Actions.runBlocking(
        //  drive.actionBuilder(beginPose)
        //       .strafeTo(new Vector2d(0, -30))
        // .strafeTo(new Vector2d(0, -35))
        //   .splineToSplineHeading(new Pose2d(47, -50, Math.toRadians(180)), Math.toRadians(180))
        // .strafeTo(new Vector2d(47, -65))
        //     .build());

        //Actions.runBlocking(
        //  drive.actionBuilder(beginPose)
        //    .splineToSplineHeading(new Pose2d(-5, -35, Math.toRadians(0)), Math.toRadians(0))
        //     .strafeTo(new Vector2d(-5, -30))
        //    .strafeTo(new Vector2d(-5, -35))
        //   .splineToSplineHeading(new Pose2d(47, -50, Math.toRadians(180)), Math.toRadians(180))
        //       .build());

        //   Actions.runBlocking(
        //      drive.actionBuilder(beginPose)
        // .strafeTo(new Vector2d(47, -65))
        // .splineToSplineHeading(new Pose2d(-10, -35, Math.toRadians(0)), Math.toRadians(0))
        // .strafeTo(new Vector2d(-10, -30))
        // .strafeTo(new Vector2d(-10, -35))
        //.strafeTo(new Vector2d(60, -65))
        //.build());
    }
}

